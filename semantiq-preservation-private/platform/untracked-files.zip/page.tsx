"use client";

import { useEffect, useMemo, useState } from "react";
import { useSearchParams } from "next/navigation";
import { listRuns, getRunResults } from "@/lib/api";
import { Badge } from "@/components/ui/badge";
import { ResponsiveContainer, LineChart, CartesianGrid, XAxis, YAxis, Tooltip, Legend, Line } from "recharts";

type ProviderInfo = { run_id: number; provider?: string; model_name?: string };
type Answer = { id: number; benchmark_id: string; answer_text: string; usage?: Record<string, any>; prompt?: string | null };

function formatDuration(ms: number): string {
  const seconds = Math.floor(ms / 1000);
  const m = Math.floor(seconds / 60);
  const s = seconds % 60;
  return `${m}m ${s}s`;
}

function diffWords(a: string, b: string): { aParts: Array<{ t: string; type: "same" | "del" }>; bParts: Array<{ t: string; type: "same" | "add" }>; } {
  const aw = a.split(/\s+/);
  const bw = b.split(/\s+/);
  const max = Math.max(aw.length, bw.length);
  const aParts: Array<{ t: string; type: "same" | "del" }> = [];
  const bParts: Array<{ t: string; type: "same" | "add" }> = [];
  for (let i = 0; i < max; i++) {
    const at = aw[i] || "";
    const bt = bw[i] || "";
    if (at === bt) {
      if (at) {
        aParts.push({ t: at, type: "same" });
        bParts.push({ t: bt, type: "same" });
      }
    } else {
      if (at) aParts.push({ t: at, type: "del" });
      if (bt) bParts.push({ t: bt, type: "add" });
    }
  }
  return { aParts, bParts };
}

export default function AnalysisPage() {
  const params = useSearchParams();
  const [providers, setProviders] = useState<Record<number, ProviderInfo>>({});
  const [answers, setAnswers] = useState<Record<number, Answer[]>>({});
  const [modalRow, setModalRow] = useState<{ pid: string; a?: string; b?: string; aLabel?: string; bLabel?: string } | null>(null);
  const [filterErrors, setFilterErrors] = useState(false);
  const [prefFilter, setPrefFilter] = useState<"all" | "A" | "B" | "Tie">("all");
  const [humanPrefs, setHumanPrefs] = useState<Record<string, "A" | "B" | "Tie">>({});

  const runIds = useMemo(() => {
    const raw = params.get("runs") || "";
    return raw.split(",").map((s) => parseInt(s, 10)).filter((n) => !Number.isNaN(n));
  }, [params]);

  useEffect(() => {
    let mounted = true;
    async function load() {
      const all = await listRuns();
      const map: Record<number, ProviderInfo> = {};
      for (const rid of runIds) {
        const item = all.find((x) => x.run_id === rid);
        if (item) map[rid] = { run_id: rid, provider: item.provider, model_name: item.model_name };
      }
      if (!mounted) return;
      setProviders(map);
      const ansMap: Record<number, Answer[]> = {};
      for (const rid of runIds) {
        const res = await getRunResults(rid);
        ansMap[rid] = res.answers || [];
      }
      if (!mounted) return;
      setAnswers(ansMap);
    }
    if (runIds.length) load();
    return () => { mounted = false; };
  }, [runIds]);

  const promptIds = useMemo(() => {
    const set = new Set<string>();
    Object.values(answers).forEach((arr) => arr.forEach((a) => set.add(a.benchmark_id)));
    return Array.from(set).sort();
  }, [answers]);

  const providerLabels = useMemo(() => {
    const vals = Object.values(providers);
    if (vals.length < 2) return [];
    return vals.map((p) => ({ id: p.run_id, label: `${p.provider || "?"} (${p.model_name || "-"})`, key: p.provider || String(p.run_id) }));
  }, [providers]);

  const kpis = useMemo(() => {
    let totalLatency = 0;
    let totalCost = 0;
    let costKnown = false;
    const perProviderLatency: Record<string, number[]> = {};
    const successes: Set<string> = new Set();
    const expectedTotal = promptIds.length * providerLabels.length;
    for (const rid of runIds) {
      const provKey = providers[rid]?.provider || String(rid);
      const arr = answers[rid] || [];
      for (const a of arr) {
        const lat = (a.usage?.latency_ms as number) || 0;
        totalLatency += lat;
        perProviderLatency[provKey] = perProviderLatency[provKey] || [];
        if (lat) perProviderLatency[provKey].push(lat);
        const cost = (a.usage?.cost as number) ?? null;
        if (cost !== null) {
          totalCost += Number(cost);
          costKnown = true;
        }
        successes.add(`${a.benchmark_id}:${provKey}`);
      }
    }
    const providerAvgLatency = Object.entries(perProviderLatency).map(([k, arr]) => ({ provider: k, avg: arr.length ? (arr.reduce((s, v) => s + v, 0) / arr.length) : 0 }));
    return {
      totalDurationMs: totalLatency,
      totalCost: costKnown ? totalCost : null,
      providerAvgLatency,
      successCount: successes.size,
      expectedTotal,
    };
  }, [answers, providers, runIds, providerLabels, promptIds]);

  const latencyChartData = useMemo(() => {
    const rows: Array<Record<string, any>> = [];
    promptIds.forEach((pid, idx) => {
      const row: Record<string, any> = { promptId: idx + 1 };
      for (const p of providerLabels) {
        const rid = p.id;
        const entry = (answers[rid] || []).find((a) => a.benchmark_id === pid);
        row[p.key] = entry?.usage?.latency_ms ?? null;
      }
      rows.push(row);
    });
    return rows;
  }, [promptIds, providerLabels, answers]);

  const tokenChartData = useMemo(() => {
    const rows: Array<Record<string, any>> = [];
    promptIds.forEach((pid, idx) => {
      const row: Record<string, any> = { promptId: idx + 1 };
      for (const p of providerLabels) {
        const rid = p.id;
        const entry = (answers[rid] || []).find((a) => a.benchmark_id === pid);
        row[p.key] = entry?.usage?.output_tokens ?? null;
      }
      rows.push(row);
    });
    return rows;
  }, [promptIds, providerLabels, answers]);

  function exportCSV() {
    const headers = ["Prompt", ...providerLabels.map((p) => p.label)];
    const rows = promptIds.map((pid) => {
      const promptText = Object.values(answers)[0]?.find((a) => a.benchmark_id === pid)?.prompt || pid;
      const cols = providerLabels.map((p) => {
        const rid = p.id;
        const entry = (answers[rid] || []).find((a) => a.benchmark_id === pid);
        return (entry?.answer_text || "").replace(/\r?\n/g, " ");
      });
      return [promptText, ...cols];
    });
    const csv = [headers, ...rows].map((row) => row.map((cell) => `"${String(cell).replace(/"/g, '""')}"`).join(",")).join("\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "analysis_results.csv";
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }

  function exportJSON() {
    const data = promptIds.map((pid) => {
      const promptText = Object.values(answers)[0]?.find((a) => a.benchmark_id === pid)?.prompt || null;
      const models: Record<string, any> = {};
      for (const p of providerLabels) {
        const rid = p.id;
        const entry = (answers[rid] || []).find((a) => a.benchmark_id === pid);
        models[p.key] = {
          answer: entry?.answer_text || null,
          usage: entry?.usage || {},
        };
      }
      return { benchmark_id: pid, prompt: promptText, models };
    });
    const blob = new Blob([JSON.stringify({ runs: runIds, data }, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "analysis_results.json";
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }

  const filteredPromptIds = useMemo(() => {
    return promptIds.filter((pid) => {
      const hasError = providerLabels.some((p) => {
        const rid = p.id;
        return !(answers[rid] || []).find((a) => a.benchmark_id === pid);
      });
      if (filterErrors && !hasError) return false;
      const pref = humanPrefs[pid];
      if (prefFilter !== "all" && pref !== prefFilter) return false;
      return true;
    });
  }, [promptIds, providerLabels, answers, filterErrors, humanPrefs, prefFilter]);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="text-xl font-semibold">Analyse: Batch #{new Date().toISOString().slice(0, 10)}</div>
        <div className="flex items-center gap-2">
          <button
            className="rounded-md border border-gray-700 px-3 py-1 text-sm hover:bg-background-lighter"
            onClick={exportCSV}
          >
            Als CSV exportieren
          </button>
          <button
            className="rounded-md border border-gray-700 px-3 py-1 text-sm hover:bg-background-lighter"
            onClick={exportJSON}
          >
            Als JSON exportieren
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-6 md:grid-cols-4">
        <div className="md:col-span-1 rounded-lg border border-gray-800 p-4">
          <div className="text-sm text-gray-400">Total Duration</div>
          <div className="text-2xl font-semibold">{formatDuration(kpis.totalDurationMs)}</div>
        </div>
        <div className="md:col-span-1 rounded-lg border border-gray-800 p-4">
          <div className="text-sm text-gray-400">Total Cost</div>
          <div className="text-2xl font-semibold">{kpis.totalCost != null ? `$${kpis.totalCost.toFixed(2)}` : "–"}</div>
        </div>
        <div className="md:col-span-1 rounded-lg border border-gray-800 p-4">
          <div className="text-sm text-gray-400">Avg. Latency</div>
          <div className="text-md">
            {kpis.providerAvgLatency.map((p) => (
              <span key={p.provider} className="mr-3">
                {p.provider}: {(p.avg / 1000).toFixed(2)}s
              </span>
            ))}
          </div>
        </div>
        <div className="md:col-span-1 rounded-lg border border-gray-800 p-4">
          <div className="text-sm text-gray-400">Success Rate</div>
          <div className="text-2xl font-semibold">
            {kpis.successCount}/{kpis.expectedTotal} Prompts erfolgreich
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
        <div className="rounded-lg border border-gray-800 p-4">
          <div className="font-medium mb-2">Latenz-Verteilung</div>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={latencyChartData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="promptId" />
                <YAxis />
                <Tooltip />
                <Legend />
                {providerLabels.map((p, idx) => (
                  <Line key={p.key} type="monotone" dataKey={p.key} stroke={idx === 0 ? "#2F8EFF" : "#10B981"} />
                ))}
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
        <div className="rounded-lg border border-gray-800 p-4">
          <div className="font-medium mb-2">Token-Usage</div>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={tokenChartData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="promptId" />
                <YAxis />
                <Tooltip />
                <Legend />
                {providerLabels.map((p, idx) => (
                  <Line key={p.key} type="monotone" dataKey={p.key} stroke={idx === 0 ? "#2F8EFF" : "#10B981"} />
                ))}
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      <div className="rounded-lg border border-gray-800 p-4">
        <div className="flex items-center justify-between mb-3">
          <div className="font-medium">Diff-Table</div>
          <div className="flex items-center gap-2">
            <label className="text-sm">
              <input type="checkbox" className="mr-2" checked={filterErrors} onChange={(e) => setFilterErrors(e.target.checked)} />
              Zeige nur Fehler
            </label>
            <select
              className="rounded-md border border-gray-700 bg-background px-2 py-1 text-sm"
              value={prefFilter}
              onChange={(e) => setPrefFilter(e.target.value as any)}
            >
              <option value="all">Alle</option>
              <option value="A">Modell A bevorzugt</option>
              <option value="B">Modell B bevorzugt</option>
              <option value="Tie">Gleichstand</option>
            </select>
          </div>
        </div>
        <div className="overflow-x-auto">
          <table className="min-w-full text-sm">
            <thead className="bg-background-lighter">
              <tr>
                <th className="px-4 py-2 text-left">Prompt Vorschau</th>
                <th className="px-4 py-2 text-left">Latenz / Tokens</th>
                <th className="px-4 py-2 text-left">Antwort-Differenz</th>
                <th className="px-4 py-2 text-left">Bevorzugtes Modell</th>
              </tr>
            </thead>
            <tbody>
              {filteredPromptIds.map((pid, i) => {
                const aRid = providerLabels[0]?.id;
                const bRid = providerLabels[1]?.id;
                const aEntry = aRid ? (answers[aRid] || []).find((x) => x.benchmark_id === pid) : undefined;
                const bEntry = bRid ? (answers[bRid] || []).find((x) => x.benchmark_id === pid) : undefined;
                const aLabel = providerLabels[0]?.label || "A";
                const bLabel = providerLabels[1]?.label || "B";
                const prompt = aEntry?.prompt ?? bEntry?.prompt ?? pid;
                const latA = aEntry?.usage?.latency_ms ?? null;
                const latB = bEntry?.usage?.latency_ms ?? null;
                const tokA = aEntry?.usage?.output_tokens ?? null;
                const tokB = bEntry?.usage?.output_tokens ?? null;
                return (
                  <tr key={pid} className="border-t border-gray-800 align-top">
                    <td className="px-4 py-2">
                      #{String(i + 1).padStart(2, "0")} {String(prompt).slice(0, 60)}
                    </td>
                    <td className="px-4 py-2">
                      <div>{latA != null && latB != null ? `Latenz: ${(latA / 1000).toFixed(1)}s (A) vs ${(latB / 1000).toFixed(1)}s (B)` : "–"}</div>
                      <div>{tokA != null && tokB != null ? `Tokens: ${tokA} (A) vs ${tokB} (B)` : "–"}</div>
                    </td>
                    <td className="px-4 py-2">
                      <button
                        className="rounded-md border border-gray-700 px-3 py-1 text-xs hover:bg-background-lighter"
                        onClick={() => setModalRow({ pid, a: aEntry?.answer_text, b: bEntry?.answer_text, aLabel, bLabel })}
                      >
                        Smart Diff anzeigen
                      </button>
                    </td>
                    <td className="px-4 py-2">
                      <div className="flex items-center gap-2">
                        <button
                          className="rounded-md border border-gray-700 px-3 py-1 text-xs hover:bg-background-lighter"
                          onClick={() => setHumanPrefs((prev) => ({ ...prev, [pid]: "A" }))}
                        >
                          👍 A
                        </button>
                        <button
                          className="rounded-md border border-gray-700 px-3 py-1 text-xs hover:bg-background-lighter"
                          onClick={() => setHumanPrefs((prev) => ({ ...prev, [pid]: "Tie" }))}
                        >
                          Tie
                        </button>
                        <button
                          className="rounded-md border border-gray-700 px-3 py-1 text-xs hover:bg-background-lighter"
                          onClick={() => setHumanPrefs((prev) => ({ ...prev, [pid]: "B" }))}
                        >
                          B 👍
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {modalRow && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70">
          <div className="w-full max-w-4xl rounded-lg border border-gray-800 bg-background p-4">
            <div className="flex items-center justify-between mb-3">
              <div className="text-lg font-semibold">Diff: {modalRow.aLabel} vs {modalRow.bLabel}</div>
              <button
                className="rounded-md border border-gray-700 px-3 py-1 text-sm hover:bg-background-lighter"
                onClick={() => setModalRow(null)}
              >
                Schließen
              </button>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="rounded-md border border-gray-700 p-3 text-sm whitespace-pre-wrap">
                {(() => {
                  const { aParts } = diffWords(modalRow.a || "", modalRow.b || "");
                  return aParts.map((p, idx) => (
                    <span key={idx} className={p.type === "del" ? "bg-red-900/40" : ""}>{p.t} </span>
                  ));
                })()}
              </div>
              <div className="rounded-md border border-gray-700 p-3 text-sm whitespace-pre-wrap">
                {(() => {
                  const { bParts } = diffWords(modalRow.a || "", modalRow.b || "");
                  return bParts.map((p, idx) => (
                    <span key={idx} className={p.type === "add" ? "bg-green-900/30" : ""}>{p.t} </span>
                  ));
                })()}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
