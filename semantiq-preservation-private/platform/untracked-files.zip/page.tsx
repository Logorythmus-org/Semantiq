"use client";

import { useEffect, useMemo, useState } from "react";
import { playgroundRun, getRun, getRunResults } from "@/lib/api";
import { Badge } from "@/components/ui/badge";

type ProviderOption = {
  provider: "openai" | "grok" | "openrouter";
  label: string;
  defaultModel: string;
};

const PROVIDERS: ProviderOption[] = [
  { provider: "openai", label: "OpenAI", defaultModel: "gpt-4o-mini" },
  { provider: "grok", label: "Grok", defaultModel: "grok-2-mini" },
  { provider: "openrouter", label: "OpenRouter", defaultModel: "openrouter/auto" },
];

export default function BatchComparePage() {
  const [showKeys, setShowKeys] = useState(false);
  const [selected, setSelected] = useState<Record<string, boolean>>({
    openai: true,
    grok: false,
    openrouter: false,
  });
  const [models, setModels] = useState<Record<string, string>>({
    openai: "gpt-4o-mini",
    grok: "grok-2-mini",
    openrouter: "openrouter/auto",
  });
  const [temps, setTemps] = useState<Record<string, number>>({
    openai: 0.2,
    grok: 0.2,
    openrouter: 0.2,
  });
  const [maxTokens, setMaxTokens] = useState<Record<string, number>>({
    openai: 256,
    grok: 256,
    openrouter: 256,
  });
  const [systemPrompt, setSystemPrompt] = useState("");
  const [batchInput, setBatchInput] = useState("");
  const [csvName, setCsvName] = useState<string>("");
  const [csvCount, setCsvCount] = useState<number>(0);
  const [isRunning, setIsRunning] = useState(false);
  const [runs, setRuns] = useState<number[]>([]);
  const [runStatus, setRunStatus] = useState<Record<number, string>>({});
  const [answersByPrompt, setAnswersByPrompt] = useState<Record<string, Record<string, string>>>({});
  const [promptIds, setPromptIds] = useState<string[]>([]);
  const [providerByRun, setProviderByRun] = useState<Record<number, string>>({});

  const providerKeys = useMemo(() => {
    return {
      openai: typeof window !== "undefined" ? localStorage.getItem("semantiq_api_key_openai") || "" : "",
      grok: typeof window !== "undefined" ? localStorage.getItem("semantiq_api_key_grok") || "" : "",
      openrouter: typeof window !== "undefined" ? localStorage.getItem("semantiq_api_key_openrouter") || "" : "",
    };
  }, []);

  const selectedProviders = PROVIDERS.filter((p) => selected[p.provider]);

  useEffect(() => {
    if (!runs.length) return;
    let mounted = true;
    const tick = async () => {
      for (const id of runs) {
        try {
          const r = await getRun(id);
          if (!mounted) return;
          setRunStatus((prev) => ({ ...prev, [id]: r.status }));
          if (r.status === "completed") {
            const res = await getRunResults(id);
            const provider = providerByRun[id];
            const byPrompt: Record<string, Record<string, string>> = {};
            for (const a of res.answers || []) {
              const pid = a.benchmark_id;
              const text = a.answer_text;
              byPrompt[pid] = byPrompt[pid] || {};
              byPrompt[pid][provider] = text;
            }
            setAnswersByPrompt((prev) => {
              const next = { ...prev };
              for (const pid of Object.keys(byPrompt)) {
                next[pid] = { ...(next[pid] || {}), ...byPrompt[pid] };
              }
              return next;
            });
          }
        } catch {
          // ignore
        }
      }
    };
    const t = setInterval(tick, 1200);
    tick();
    return () => {
      mounted = false;
      clearInterval(t);
    };
  }, [runs, providerByRun]);

  useEffect(() => {
    if (!runs.length) return;
    const allDone = runs.every((r) => runStatus[r] === "completed");
    if (allDone) {
      const params = new URLSearchParams({ runs: runs.join(",") });
      if (typeof window !== "undefined") {
        window.location.href = `/analysis?${params.toString()}`;
      }
    }
  }, [runs, runStatus]);

  function parsePrompts(input: string, system?: string): { ids: string[]; data: Array<{ id: string; module: string; prompt_text: string; dimensions: string[] }> } {
    const lines = input.split(/\r?\n/).map((l) => l.trim()).filter((l) => l.length > 0);
    const ids = lines.map((_, i) => `BATCH-${i + 1}`);
    const prefix = system?.trim() ? `System:\n${system.trim()}\n\nUser:\n` : "";
    const data = lines.map((u, i) => ({
      id: ids[i],
      module: "batch",
      prompt_text: `${prefix}${u}`,
      dimensions: [],
    }));
    return { ids, data };
  }

  async function onRunBatch() {
    const parsed = parsePrompts(batchInput, systemPrompt);
    if (!parsed.ids.length || !selectedProviders.length) return;
    setIsRunning(true);
    setRuns([]);
    setRunStatus({});
    setAnswersByPrompt({});
    setPromptIds(parsed.ids);
    const modelsPayload = selectedProviders.map((p) => ({
      provider: p.provider,
      model_name: models[p.provider] || p.defaultModel,
      temperature: temps[p.provider],
      max_tokens: maxTokens[p.provider],
      api_key: (providerKeys as any)[p.provider] || undefined,
    }));
    try {
      const resp = await playgroundRun({
        models: modelsPayload,
        benchmarks_data: parsed.data,
      });
      const runIds = resp.runs || [];
      const mapping: Record<number, string> = {};
      runIds.forEach((rid, idx) => {
        const p = selectedProviders[idx];
        mapping[rid] = p.provider;
      });
      setProviderByRun(mapping);
      setRuns(runIds);
    } catch {
      // ignore
    } finally {
      setIsRunning(false);
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="text-xl font-semibold">Batch & Compare</div>
        <button
          className="rounded-md border border-gray-700 px-3 py-1 text-sm hover:bg-background-lighter"
          onClick={() => setShowKeys(true)}
        >
          API-Schlüssel verwalten
        </button>
      </div>

      <div className="grid grid-cols-1 gap-6 md:grid-cols-3">
        <div className="md:col-span-1 space-y-4">
          <div className="rounded-lg border border-gray-800 p-4">
            <div className="font-medium mb-2">Anbieter & Modelle</div>
            {PROVIDERS.map((p) => (
              <label key={p.provider} className="block mb-3">
                <input
                  type="checkbox"
                  className="mr-2"
                  checked={!!selected[p.provider]}
                  onChange={(e) =>
                    setSelected((prev) => ({ ...prev, [p.provider]: e.target.checked }))
                  }
                />
                {p.label}
                {selected[p.provider] && (
                  <div className="mt-2 ml-6 space-y-2">
                    <input
                      className="w-full rounded-md border border-gray-700 bg-background px-2 py-1 text-sm"
                      value={models[p.provider] || ""}
                      onChange={(e) =>
                        setModels((prev) => ({ ...prev, [p.provider]: e.target.value }))
                      }
                      placeholder={`Modellname (z.B. ${p.defaultModel})`}
                    />
                    <div className="flex gap-2">
                      <input
                        type="number"
                        step="0.1"
                        className="w-1/2 rounded-md border border-gray-700 bg-background px-2 py-1 text-sm"
                        value={temps[p.provider] ?? 0.2}
                        onChange={(e) =>
                          setTemps((prev) => ({ ...prev, [p.provider]: parseFloat(e.target.value) }))
                        }
                        placeholder="Temperature"
                      />
                      <input
                        type="number"
                        className="w-1/2 rounded-md border border-gray-700 bg-background px-2 py-1 text-sm"
                        value={maxTokens[p.provider] ?? 256}
                        onChange={(e) =>
                          setMaxTokens((prev) => ({
                            ...prev,
                            [p.provider]: parseInt(e.target.value, 10),
                          }))
                        }
                        placeholder="Max Tokens"
                      />
                    </div>
                  </div>
                )}
              </label>
            ))}
          </div>

          <button
            className="w-full rounded-md bg-electric px-3 py-2 text-sm font-medium text-black disabled:opacity-50"
            onClick={onRunBatch}
            disabled={isRunning || !batchInput.trim() || !selectedProviders.length}
          >
            Batch ausführen
          </button>
        </div>

        <div className="md:col-span-2 space-y-4">
          <div className="rounded-lg border border-gray-800 p-4">
            <div className="font-medium mb-2">System Prompt</div>
            <textarea
              className="min-h-[80px] w-full rounded-md border border-gray-700 bg-background px-2 py-1 text-sm"
              value={systemPrompt}
              onChange={(e) => setSystemPrompt(e.target.value)}
              placeholder="Optional: Richtlinien, Rollen, Ziele..."
            />
          </div>
          <div className="rounded-lg border border-gray-800 p-4">
            <div className="font-medium mb-2">Batch Input (mehrere Zeilen, jede ein Prompt)</div>
            <textarea
              className="min-h-[200px] w-full rounded-md border border-gray-700 bg-background px-2 py-1 text-sm"
              value={batchInput}
              onChange={(e) => setBatchInput(e.target.value)}
              placeholder="Beispiel:\nSchreibe ein Haiku über Winter.\nErkläre Quantenverschränkung in einfachen Worten.\n..."
            />
            <div className="mt-3">
              <div className="text-sm text-gray-400 mb-2">CSV Import</div>
              <div
                className="rounded-md border border-dashed border-gray-700 p-4 text-xs text-gray-400"
                onDragOver={(e) => e.preventDefault()}
                onDrop={(e) => {
                  e.preventDefault();
                  const file = e.dataTransfer.files?.[0];
                  if (!file) return;
                  const reader = new FileReader();
                  reader.onload = () => {
                    const text = String(reader.result || "");
                    const lines = text.split(/\r?\n/).map((l) => l.trim()).filter((l) => l.length > 0);
                    const prompts = lines.map((line) => {
                      const first = line.split(",")[0] || "";
                      return first.replace(/^"(.+)"$/, "$1");
                    }).filter((p) => p.length > 0);
                    setBatchInput(prompts.join("\n"));
                    setCsvName(file.name);
                    setCsvCount(prompts.length);
                  };
                  reader.readAsText(file);
                }}
              >
                Datei hierher ziehen oder wählen
                <input
                  type="file"
                  accept=".csv,text/csv"
                  className="mt-2 block"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (!file) return;
                    const reader = new FileReader();
                    reader.onload = () => {
                      const text = String(reader.result || "");
                      const lines = text.split(/\r?\n/).map((l) => l.trim()).filter((l) => l.length > 0);
                      const prompts = lines.map((line) => {
                        const first = line.split(",")[0] || "";
                        return first.replace(/^"(.+)"$/, "$1");
                      }).filter((p) => p.length > 0);
                      setBatchInput(prompts.join("\n"));
                      setCsvName(file.name);
                      setCsvCount(prompts.length);
                    };
                    reader.readAsText(file);
                  }}
                />
                {!!csvName && (
                  <div className="mt-2 text-xs text-gray-500">
                    {csvName} • {csvCount} Prompts geladen
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>

      {!!promptIds.length && (
        <div className="rounded-lg border border-gray-800 p-4">
          <div className="flex items-center justify-between mb-4">
            <div className="font-medium">Ergebnisse</div>
            <div className="flex items-center gap-3">
              {runs.length > 0 && (
                <div className="text-xs text-gray-400">
                  Fortschritt: {Object.values(runStatus).filter((s) => s === "completed").length}/{runs.length} abgeschlossen
                </div>
              )}
              <button
                className="rounded-md border border-gray-700 px-3 py-1 text-xs hover:bg-background-lighter"
                onClick={() => {
                  const headers = ["Prompt", ...selectedProviders.map((p) => p.label)];
                  const rows = promptIds.map((pid, i) => {
                    const promptText = (batchInput.split(/\r?\n/).filter((l) => l.trim().length > 0)[i] || "").replace(/\r?\n/g, " ");
                    const cols = selectedProviders.map((p) => (answersByPrompt[pid]?.[p.provider] || "").replace(/\r?\n/g, " "));
                    return [promptText, ...cols];
                  });
                  const csv = [headers, ...rows].map((row) =>
                    row.map((cell) => `"${String(cell).replace(/"/g, '""')}"`).join(",")
                  ).join("\n");
                  const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
                  const url = URL.createObjectURL(blob);
                  const a = document.createElement("a");
                  a.href = url;
                  a.download = "batch_results.csv";
                  document.body.appendChild(a);
                  a.click();
                  document.body.removeChild(a);
                  URL.revokeObjectURL(url);
                }}
              >
                CSV exportieren
              </button>
            </div>
          </div>
          <div className="overflow-x-auto">
            <table className="min-w-full text-sm">
              <thead className="bg-background-lighter">
                <tr>
                  <th className="px-4 py-2 text-left">Prompt</th>
                  {selectedProviders.map((p) => (
                    <th key={p.provider} className="px-4 py-2 text-left">
                      <div className="flex items-center gap-2">
                        <span>{p.label}</span>
                        {runs.length > 0 && (
                          <Badge className="border-gray-600">
                            {runStatus[runs[selectedProviders.indexOf(p)]] || "pending"}
                          </Badge>
                        )}
                      </div>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {promptIds.map((pid, i) => (
                  <tr key={pid} className="border-t border-gray-800 align-top">
                    <td className="px-4 py-2">
                      {pid.replace("BATCH-", "")}. {(
                        batchInput.split(/\r?\n/).filter((l) => l.trim().length > 0)[i] || ""
                      )}
                    </td>
                    {selectedProviders.map((p) => (
                      <td key={`${pid}-${p.provider}`} className="px-4 py-2 whitespace-pre-wrap">
                        {answersByPrompt[pid]?.[p.provider] || "Warten auf Antwort..."}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {showKeys && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70">
          <div className="w-full max-w-lg rounded-lg border border-gray-800 bg-background p-4">
            <div className="text-lg font-semibold mb-2">API-Schlüssel verwalten</div>
            <div className="text-sm text-gray-400 mb-4">
              Schlüssel werden lokal gespeichert und nur für die Anfrage genutzt.
            </div>
            <div className="space-y-3">
              <div>
                <div className="text-sm mb-1">OpenAI</div>
                <input
                  className="w-full rounded-md border border-gray-700 bg-background px-2 py-1 text-sm"
                  defaultValue={providerKeys.openai}
                  onChange={(e) => localStorage.setItem("semantiq_api_key_openai", e.target.value)}
                  placeholder="sk-..." />
              </div>
              <div>
                <div className="text-sm mb-1">Grok</div>
                <input
                  className="w-full rounded-md border border-gray-700 bg-background px-2 py-1 text-sm"
                  defaultValue={providerKeys.grok}
                  onChange={(e) => localStorage.setItem("semantiq_api_key_grok", e.target.value)}
                  placeholder="gsk-..." />
              </div>
              <div>
                <div className="text-sm mb-1">OpenRouter</div>
                <input
                  className="w-full rounded-md border border-gray-700 bg-background px-2 py-1 text-sm"
                  defaultValue={providerKeys.openrouter}
                  onChange={(e) => localStorage.setItem("semantiq_api_key_openrouter", e.target.value)}
                  placeholder="or-..." />
              </div>
            </div>
            <div className="mt-4 flex justify-end gap-2">
              <button
                className="rounded-md border border-gray-700 px-3 py-1 text-sm hover:bg-background-lighter"
                onClick={() => setShowKeys(false)}
              >
                Schließen
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
