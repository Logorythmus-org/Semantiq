"use client";

export default function ResearchPage() {
  return (
    <div className="space-y-6">
      <div className="text-xl font-semibold">Research / Papers</div>
      <div className="rounded-lg border border-gray-800 p-4">
        <div className="text-sm text-gray-400 mb-2">Paper View</div>
        <div className="text-sm text-gray-300">
          Lesefreundliches Layout ohne Ablenkung. Hier können Kurzzusammenfassungen, Abstracts und Highlights angezeigt werden.
        </div>
      </div>
    </div>
  );
}

