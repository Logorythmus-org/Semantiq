"use client";

export default function ProfilePage() {
  return (
    <div className="space-y-6">
      <div className="text-xl font-semibold">User Profile</div>
      <div className="rounded-lg border border-gray-800 p-4">
        <div className="text-sm text-gray-400">Profil-Einstellungen sind bald verfügbar.</div>
      </div>
    </div>
  );
}

