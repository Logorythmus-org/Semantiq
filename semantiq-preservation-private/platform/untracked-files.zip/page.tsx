"use client";

import { useEffect, useMemo, useState } from "react";
import { Card, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import Link from "next/link";
import { listPrompts, createPrompt, listBenchmarks } from "@/lib/api";
import { Badge } from "@/components/ui/badge";

type PromptItem = {
  id: string;
  title: string;
  tags: string[];
  variables: string[];
  version?: string;
  content: string;
};

export default function LibraryPage() {
  const [items, setItems] = useState<PromptItem[]>([]);
  const [benchmarks, setBenchmarks] = useState<Array<{ id: string; module: string; prompt: string; dimensions: string[] }>>([]);
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [tags, setTags] = useState("");
  const [version, setVersion] = useState("");
  const PROVIDERS = [
    { provider: "openai", label: "OpenAI", defaultModel: "gpt-4o-mini" },
    { provider: "grok", label: "Grok", defaultModel: "grok-2-mini" },
    { provider: "openrouter", label: "OpenRouter", defaultModel: "openrouter/auto" },
  ];
  const [selected, setSelected] = useState<Record<string, boolean>>({ openai: true, grok: false, openrouter: false });
  const [models, setModels] = useState<Record<string, string>>({
    openai: "gpt-4o-mini",
    grok: "grok-2-mini",
    openrouter: "openrouter/auto",
  });

  useEffect(() => {
    let mounted = true;
    async function load() {
      try {
        const res = await listPrompts();
        if (!mounted) return;
        setItems(res as any);
      } catch {
        // ignore
      }
      try {
        const b = await listBenchmarks();
        if (!mounted) return;
        setBenchmarks(b || []);
      } catch {
        // ignore
      }
    }
    load();
    return () => { mounted = false; };
  }, []);

  const filterTags = useMemo(() => {
    const set = new Set<string>();
    items.forEach((i) => (i.tags || []).forEach((t) => set.add(t)));
    return Array.from(set).sort();
  }, [items]);

  async function onCreate() {
    const id = title.toLowerCase().replace(/\s+/g, "-").replace(/[^a-z0-9\-]/g, "");
    const vars = Array.from(new Set((content.match(/\{\{([^}]+)\}\}/g) || []).map((m) => m.replace(/[{}]/g, ""))));
    try {
      await createPrompt({ id, title, content, tags: tags.split(",").map((t) => t.trim()).filter(Boolean), variables: vars, version: version || undefined });
      const res = await listPrompts();
      setItems(res as any);
      setTitle("");
      setContent("");
      setTags("");
      setVersion("");
    } catch {
      // ignore
    }
  }

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 gap-6 md:grid-cols-3">
        <div className="md:col-span-2">
          <div className="flex items-center justify-between">
            <div className="text-xl font-semibold">Prompt Library</div>
            <div className="flex items-center gap-2">
              {filterTags.map((t) => (
                <span key={t} className="rounded-md border border-gray-700 px-2 py-1 text-xs">{t}</span>
              ))}
            </div>
          </div>
        </div>
        <div className="md:col-span-1">
          <div className="rounded-lg border border-gray-800 p-4">
            <div className="font-medium mb-2">Anbieter & Modelle</div>
            {PROVIDERS.map((p) => (
              <label key={p.provider} className="block mb-3">
                <input
                  type="checkbox"
                  className="mr-2"
                  checked={!!selected[p.provider]}
                  onChange={(e) =>
                    setSelected((prev) => ({ ...prev, [p.provider]: e.target.checked }))
                  }
                />
                {p.label}
                {selected[p.provider] && (
                  <div className="mt-2 ml-6">
                    <input
                      className="w-full rounded-md border border-gray-700 bg-background px-2 py-1 text-sm"
                      value={models[p.provider] || ""}
                      onChange={(e) =>
                        setModels((prev) => ({ ...prev, [p.provider]: e.target.value }))
                      }
                      placeholder={`Modellname (z.B. ${p.defaultModel})`}
                    />
                  </div>
                )}
              </label>
            ))}
            <div className="mt-3 text-xs text-gray-400">
              Auswahl wird für „Open in Playground“ genutzt.
            </div>
          </div>
        </div>
      </div>

      <div className="rounded-lg border border-gray-800 p-4">
        <div className="font-medium mb-2">Neuen Prompt speichern</div>
        <div className="grid grid-cols-1 gap-3 md:grid-cols-4">
          <input className="rounded-md border border-gray-700 bg-background px-2 py-1 text-sm" placeholder="Titel" value={title} onChange={(e) => setTitle(e.target.value)} />
          <input className="rounded-md border border-gray-700 bg-background px-2 py-1 text-sm" placeholder="Version (optional)" value={version} onChange={(e) => setVersion(e.target.value)} />
          <input className="rounded-md border border-gray-700 bg-background px-2 py-1 text-sm" placeholder="Tags (kommagetrennt)" value={tags} onChange={(e) => setTags(e.target.value)} />
          <Button onClick={onCreate} disabled={!title.trim() || !content.trim()}>Speichern</Button>
        </div>
        <textarea className="mt-3 min-h-[120px] w-full rounded-md border border-gray-700 bg-background px-2 py-1 text-sm" placeholder="Prompt-Inhalt (Unterstützt {{variable}})" value={content} onChange={(e) => setContent(e.target.value)} />
      </div>

      <div className="rounded-lg border border-gray-800 p-4">
        <div className="flex items-center justify-between mb-2">
          <div className="font-medium">Benchmarks</div>
          <Badge className="border-gray-600">{benchmarks.length}</Badge>
        </div>
        <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
          {benchmarks.map((b) => (
            <div key={b.id} className="rounded-md border border-gray-700 p-3">
              <div className="flex items-center justify-between">
                <div className="text-sm font-medium">{b.module} • {b.id}</div>
                <div className="text-xs text-gray-500">{(b.dimensions || []).join(", ")}</div>
              </div>
              <div className="mt-2 text-xs text-gray-400 whitespace-pre-wrap">{b.prompt.slice(0, 240)}{b.prompt.length > 240 ? "…" : ""}</div>
              <div className="mt-3 flex items-center gap-2">
                <Button
                  size="sm"
                  onClick={() => {
                    setTitle(`${b.module} • ${b.id}`);
                    setContent(b.prompt);
                    setTags((b.dimensions || []).join(", "));
                    setVersion("v1.0");
                  }}
                >
                  In Library übernehmen
                </Button>
                <Button
                  size="sm"
                  variant="ghost"
                  className="border border-gray-700"
                  onClick={() => {
                    const providers = Object.keys(selected).filter((k) => selected[k]);
                    const modelsParam = providers.map((p) => `${p}:${encodeURIComponent(models[p] || "")}`).join(",");
                    const url = `/run?prompt=${encodeURIComponent(b.prompt)}&providers=${encodeURIComponent(providers.join(","))}&models=${modelsParam}`;
                    window.location.href = url;
                  }}
                >
                  Open in Playground
                </Button>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
        {items.map((p) => (
          <Card key={p.id}>
            <CardTitle>{p.title}</CardTitle>
            <div className="mb-2 text-xs text-gray-500">{p.version || "v1.0"}</div>
            <div className="mb-3 flex flex-wrap gap-1">
              {(p.tags || []).map((t) => (
                <span key={t} className="rounded-md border border-gray-700 px-2 py-0.5 text-xs">{t}</span>
              ))}
              {(p.variables || []).map((v) => (
                <span key={v} className="rounded-md border border-gray-700 px-2 py-0.5 text-xs bg-gray-800">var:{v}</span>
              ))}
            </div>
            <div className="text-xs text-gray-400 mb-3 whitespace-pre-wrap">
              {p.content.slice(0, 200)}{p.content.length > 200 ? "…" : ""}
            </div>
            <div className="flex items-center gap-2">
              <Button
                size="sm"
                onClick={() => {
                  const providers = Object.keys(selected).filter((k) => selected[k]);
                  const modelsParam = providers.map((pv) => `${pv}:${encodeURIComponent(models[pv] || "")}`).join(",");
                  const url = `/run?prompt=${encodeURIComponent(p.content)}&providers=${encodeURIComponent(providers.join(","))}&models=${modelsParam}`;
                  window.location.href = url;
                }}
              >
                Open in Playground
              </Button>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}
